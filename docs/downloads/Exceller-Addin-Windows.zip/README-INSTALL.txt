Exceller - Excel Add-in
===========================

WHAT YOU GOT
------------
This folder installs Exceller as a native Microsoft Excel add-in.
It adds an "Exceller" toolbar with one-click commands:

  Exceller_Chat           Ask anything about your data
  Exceller_Analyze        Insights from the selected range
  Exceller_FixFormula     Repair broken formulas
  Exceller_VerifyFormula  Check if a formula is correct
  Exceller_CreateTable    Format data as a professional table
  Exceller_SuggestPrice   Price calculation help
  Exceller_GetFormulaHelp Formula suggestions on demand
  Exceller_Settings       Set your Gemini API key

FILES
-----
  install.bat        One-click installer - double-click this
  build_addin.vbs    Compiles and registers the add-in
  ExcelAssistant.bas The Excel VBA source

HOW TO INSTALL (under a minute)
---------------------------------
1. Close Microsoft Excel if it is open.
2. Double-click install.bat
3. The installer compiles the add-in and registers it to auto-load.
4. Open Excel - Exceller is ready. (Alt+F8 lists every command.)

NO PYTHON NEEDED. The installer uses only Windows built-in tools.

GETTING STARTED
----------------
1. Press Alt+F8
2. Run Exceller_Settings
3. Paste your free Gemini API key
   (get one at https://aistudio.google.com/app/apikey)
4. Select a range in Excel and run Exceller_Chat to start.

Need help? support@exceller.app