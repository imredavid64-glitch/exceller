@echo off
title Exceller - One-Click Excel Add-in Installer
setlocal
echo ========================================
echo   EXCELLER - ONE-CLICK INSTALLER
echo   (No Python needed - just this file)
echo ========================================
echo.

REM Allow Excel macros to run and let the installer compile the add-in.
REM (HKCU only - no administrator rights needed.)
reg add "HKCU\Software\Microsoft\Office\16.0\Excel\Security" /v VBAWarnings /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Office\15.0\Excel\Security" /v VBAWarnings /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Office\14.0\Excel\Security" /v VBAWarnings /t REG_DWORD /d 1 /f >nul 2>&1

echo Building and installing the add-in...
cscript //nologo "%~dp0build_addin.vbs" "%~dp0ExcelAssistant.bas" "" "ExcelAssistant"
if %errorlevel% neq 0 (
    echo.
    echo Installation FAILED. See the error message above.
    echo Tip: close Microsoft Excel, then run this installer again.
    pause
    exit /b 1
)

echo.
echo Launching Excel - Exceller will load automatically...
start "" excel

echo.
echo ========================================
echo   INSTALLATION COMPLETE!
echo ========================================
echo.
echo Exceller is installed and will load every time Excel starts.
echo In Excel: press Alt+F8 to see all Exceller commands.
echo.
pause
endlocal