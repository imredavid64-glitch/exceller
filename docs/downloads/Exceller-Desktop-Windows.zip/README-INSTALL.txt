Exceller - AI Excel Assistant
==============================

WHAT YOU GOT
------------
This is the Exceller desktop app (Windows). It is a floating,
always-on-top assistant that works alongside Microsoft Excel.
It is powered by Google Gemini AI.

FILES
-----
  main.py            The application
  modules/           App code (AI engine, Excel parser, etc.)
  requirements.txt   Python packages used by the app
  install.bat        ONE-TIME setup - double-click this first
  run.bat            STARTS the app - double-click this to run

HOW TO INSTALL (one time, ~2-3 minutes)
----------------------------------------
1. Make sure Python 3.8+ is installed:
   https://www.python.org/downloads/
   IMPORTANT: during install, check "Add Python to PATH".
2. Double-click install.bat - it sets everything up for you.
3. Double-click run.bat to start Exceller.
   (The app appears in your system tray.)

GETTING YOUR FREE API KEY
--------------------------
Open https://aistudio.google.com/app/apikey
and copy a free Gemini API key, then edit:

  modules\ai_engine.py

and replace the API key in the AIEngine class.

TIP
---
You can also build a standalone Exceller.exe (no Python needed on
other computers) - see build.bat in the project's ExcellerApp folder.

Need help? support@exceller.app