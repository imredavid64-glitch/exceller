@echo off
title Exceller - One-Click Desktop App Installer
setlocal
echo ========================================
echo   EXCELLER - ONE-CLICK INSTALLER
echo ========================================
echo.

REM Check Python installation
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Python was not found.
    echo.
    echo Please install Python 3.8+ from https://www.python.org/downloads/
    echo IMPORTANT: check ADD PYTHON TO PATH during installation.
    echo.
    pause
    exit /b 1
)

echo Python found! Installing Exceller...
echo.

REM Create virtual environment
echo Creating virtual environment...
if not exist "venv" python -m venv venv
if %errorlevel% neq 0 (
    echo Failed to create virtual environment.
    pause
    exit /b 1
)

REM Activate virtual environment
echo Activating virtual environment...
call venv\Scripts\activate

REM Install dependencies
echo Installing dependencies (first run can take a few minutes)...
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo Failed to install dependencies.
    pause
    exit /b 1
)

echo.
echo ========================================
echo Installation Complete!
echo ========================================
echo.
echo To start Exceller, double-click "run.bat"
echo or run: python main.py
echo.
echo The app will appear in your system tray!
echo.
pause